<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class LoginController extends Controller
{
    //
    public function login(Request $request){
        $username = $request['username'];
        $password = md5($request['password']);
        $DbQuery = DB::table('user')->select('type')->where(['name'=>$username,'password'=>$password])->get();
        if(count($DbQuery)>0){
            return response()->json(['status'=>'Ok','message'=>'Login Successfull','Info'=>$DbQuery]);
        }
        else{
            return response()->json(['status'=>'Fail','message'=>'Login Failed']);
        }

    }
}
